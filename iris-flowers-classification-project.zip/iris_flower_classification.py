
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score
import pandas as pd
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings("ignore", category=UserWarning)
import seaborn as sns

data = pd.read_csv("IRIS.csv")

data.head(5)

data.isnull().sum()

data.info()

plt.figure(figsize=(10,8))
sns.heatmap(data[['sepal_length', 'sepal_width', 'petal_length', 'petal_width']].corr(), vmin=-1.0, vmax=1.0, annot=True, linewidths=2)
plt.show()

x = data[['sepal_length', 'sepal_width', 'petal_length', 'petal_width']]

x

y = data['species']

X_train, X_test, y_train, y_test = train_test_split(x, y, test_size=0.2, random_state=42)

knn = KNeighborsClassifier(n_neighbors=3)

knn.fit(X_train, y_train)

y_pred = knn.predict(X_test)

accuracy = accuracy_score(y_test, y_pred)
print("Accuracy:", accuracy)

new_data = np.array([[5.7,	2.8,	4.1,	1.3	]])
prediction = knn.predict(new_data)
print("Predicted species:", prediction)

3